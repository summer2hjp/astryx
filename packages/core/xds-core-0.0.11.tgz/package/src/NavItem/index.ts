/**
 * @file index.ts
 * @input Imports from navItemStyles.stylex.ts
 * @output Exports navItemStyles and NavItemSize type
 * @position Entry point for NavItem module
 */

export {navItemStyles} from './navItemStyles.stylex';
export type {NavItemSize} from './navItemStyles.stylex';
